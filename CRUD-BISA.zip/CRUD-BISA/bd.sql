CREATE DATABASE `bisa`;

USE `bisa`;

CREATE TABLE `cliente`(
`id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
`cpf` INT NOT NULL,
`cnpj` INT NOT NULL,
`name` VARCHAR(100) NOT NULL,
`telefone` NUMBER,
`endereco` VARCHAR(255) NOT NULL,
PRIMARY KEY(id)
)COLLATE=utf8_unicode_ci;

INSERT INTO `cliente`( id, cpf, cnpj, name, telefone, endereco) VALUES ( ' ', ' ', ' ', ' ', ' ', ' ');