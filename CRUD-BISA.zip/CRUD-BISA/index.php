<?php
require_once 'init.php';
 
// abre a conexão
$PDO = db_connect();
 
// SQL para contar o total de registros
// A biblioteca PDO possui o método rowCount(), mas ele pode ser impreciso.
// É recomendável usar a função COUNT da SQL
// Veja o Exemplo 2 deste link: http://php.net/manual/pt_BR/pdostatement.rowcount.php
$sql_count = "SELECT COUNT(*) AS total FROM cliente ORDER BY name ASC";
 
// SQL para selecionar os registros
$sql = "SELECT id, cpf, cnpj, name, telefone, endereco FROM cliente ORDER BY name ASC";
 
// conta o toal de registros
$stmt_count = $PDO->prepare($sql_count);
$stmt_count->execute();
$total = $stmt_count->fetchColumn();
 
// seleciona os registros
$stmt = $PDO->prepare($sql);
$stmt->execute();
?>
<!doctype html>
<html>
    <head>
        <meta charset="utf-8">
 
        <title>Sistema de Cadastro de Clientes</title>
    </head>
 
    <body>
         
        <div class="tex">
        	<div>
        		<h1>Bem vindo ao sistema de cadastro para clientes da BisaWeb</h1>
        	</div>
        </div>
         
         <div>
         	<div>
         		 <button><a href="form-add.php">Adicionar Cliente</a></button>
         	</div>
         </div>
      
 		<var>
 			<div>
 				<div>
 					 <h2>Lista de Usuários</h2>
 
        <table width="50%" border="1">
            <thead>
                <tr>
                    <th>Id</th>
                    <th>CPF</th>
                    <th>CNPJ</th>
                    <th>Nome</th>
                    <th>Telefone</th>
                    <th>Endereço</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($bisa = $stmt->fetch(PDO::FETCH_ASSOC)): ?>
                <tr>
                    <td><?php echo $bisa['id'] ?></td>
                    <td><?php echo $bisa['cpf'] ?></td>
                    <td><?php echo $bisa['cnpj'] ?></td>
                    <td><?php echo $bisa['name'] ?></td>
                    <td><?php echo $bisa['telefone'] ?></td>
                    <td><?php echo $bisa['endereco'] ?></td>
                   
                    <td>
                        <a href="form-edit.php?id=<?php echo $bisa['id'] ?>">Editar</a>
                        <a href="delete.php?id=<?php echo $bisa['id'] ?>" onclick="return confirm('Tem certeza de que deseja remover?');">Remover</a>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>

 				</div>
 			</div>
 		</var>
    </body>
</html>