<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	 <link rel="stylesheet" type="text/css" href="arq.css">
	 <meta name="viewport" content="width=device-width, initial-scale=1">
 	 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
	 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  	 <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
	<title>Bem vindo a BisaWeb</title>
</head>
<body>

	<!--<div class="geral">
		<div class="header">
			<h1>HEADER</h1>	
		</div> -->

		<div class="row">
			<div class="container">

  				<h2>Bem vindo ao Sistema BisaWeb</h2>

  					<a href="#" class="btn btn-info" role="button">Cadastra cliente</a>
  					
			</div>
		</div>
  
  

	<!--<div class="footer">
  <p>Footer</p>
</div> -->

</body>
</html>