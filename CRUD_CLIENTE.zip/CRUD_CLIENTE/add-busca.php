<?php

require 'init.php';

$pequisa = isset($_POST['pesquisa']) ? $_POST['pesquisa'] : null;
if($name == $pesquisa){

	$PDO = db_connect();
	$sql = ("SELECT name, cpf_cnpj, telefone, endereco  FROM cliente WHERE id LIKE '%". $name ."%'");
	$stmt = $PDO->prepare($sql);
	$stmt->bindParam(':name', $name);
	

	if($result = $stmt->execute()){

		header('Location: busca.php');
	}else {
	echo "Erro na busca de clientes";
	print_r($result = $stmt-errorInfo());
	
	}
}else{

	echo "Refaça a pesquisa de novo";
}













/*$name = $_POST['busca'];*/

/*if(isset($_POST['pesquisa'])){
	
	$PDO = db_connect();
	$sql = "SELECT name, cpf_cnpj, telefone, endereco FROM cliente WHERE cpf_cnpj LIKE '%". $valor. "%' ";
	$stmt  =$PDO->query($sql);
	$stmt->bindValue(':$valor', '%'. $name . '%', PDO::PARAM_STR);
	$stmt->execute();
	$respostas = $stmt->rowCount();
	print_r( $respostas );
	

	if($respostas >=1){

		echo "Respostas(s) encontrado(s): " .$respostas . "<br/><br />";
		while ($reg->$stmt->fetchALL(PDO::FETCH_ASSOC)) {
			
			echo $reg['name'] . "-";
			/*echo $reg['email'] ."</br>";*/
			
	/*	}
	} 
	else{
		echo "Não existe usuario cadastrado";
	}
}
else {
	echo "Preencha o campo de pesquisa";
}

// Recebe o termo de pesquisa se existir
/*$termo = (isset($_POST['termo'])) ? $_POST['termo'] : '';
 
// Verifica se o termo de pesquisa está vazio, se estiver executa uma consulta completa
if (empty($termo)):
 
	$PDO = db_connect::getInstance();
	$sql = 'SELECT id, name, cpf_cnpj, telefone, endereco FROM cliente';
	$stmt = $PDO->prepare($sql);
	$stmt->execute();
	$pesquisa = $stmt->fetchAll(PDO::FETCH_OBJ);

	print_r( $pesquisa );
 
else:
 
	// Executa uma consulta baseada no termo de pesquisa passado como parâmetro
	$PDO = db_connect::getInstance();
	$sql = 'SELECT id, name, cpf_cnpj, telefone, endereco FROM cliente WHERE name LIKE :name OR cpf_cnpj LIKE :cpf_cnpj';
	$stmt = $PDO->prepare($sql);
	$stmt->bindValue(':name', '%'.$termo.'%');
	$stmt->bindValue(':cpf_cnpj','%'.$termo.'%');
	$stmt->execute();
	$pesquisa = $stmt->fetchAll(PDO::FETCH_OBJ);
 
endif;
*/
?>
