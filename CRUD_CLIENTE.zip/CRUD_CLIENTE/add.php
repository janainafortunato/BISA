<?php
 
require_once 'init.php';
 
// pega os dados do formuário
$name = isset($_POST['name']) ? $_POST['name'] : null;
$cpf_cnpj = isset($_POST['cpf_cnpj']) ? $_POST['cpf_cnpj'] : null;
$telefone = isset($_POST['telefone']) ? $_POST['telefone'] : null;
$endereco = isset($_POST['endereco']) ? $_POST['endereco'] : null;

 
// validação pra evitar dados vazios
if (empty($name) || empty($cpf_cnpj) || empty($telefone) || empty($endereco))
{
    echo "Volte e preencha todos os campos";
    exit;
}
 
// insere no banco
$PDO = db_connect();
$sql = "INSERT INTO cliente(name, cpf_cnpj, telefone, endereco) VALUES(:name, :cpf_cnpj, :telefone, :endereco)";
$stmt = $PDO->prepare($sql);
$stmt->bindParam(':name', $name);
$stmt->bindParam(':cpf_cnpj', $cpf_cnpj);
$stmt->bindParam(':telefone', $telefone);
$stmt->bindParam(':endereco', $endereco);
  
if ($stmt->execute())
{
    header('Location: index.php');
}
else
{
    echo "Erro ao cadastrar";
    print_r($stmt->errorInfo());
}

?>