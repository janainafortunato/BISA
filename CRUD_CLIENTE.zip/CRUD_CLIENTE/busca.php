<?php

require_once 'init.php';

$PDO = db_connect();

$pesquisa = $_POST['pesquisa'];
 // SQL para selecionar os registros
$sql = ("SELECT * FROM cliente WHERE name LIKE '%" . $pesquisa . "%'");
$result = $PDO->query($sql);
$stmt = $result->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE HTML>
<html>
<head>
    <meta charset="utf-8">
    <title>Listagem de Clientes</title>
</head>
<body>
    
           <h1>Listagem de Clientes</h1>
 
            <form action="add-busca.php" method="POST" >
                <label  for="pesquisa">Pesquisar</label>
                    <input type="text"  id="pesquisa" name="pesquisa" placeholder="Infome o Nome ou E-mail">
                </div>
                <button type="submit">Pesquisar</button><br>
                <a href='index.php'>Ver Todos</a>
            </form>

           <a href='form-add.php'>Volta</a><br>

        <table width="50%" border="1">
                <thead>
                    <tr>
                        <th>Resultado</th>
                    </tr>
                </thead>
                <tbody>
                    
                    <?php foreach ($stmt as $stmts): ?>
                    <tr>
                        <td><?php echo $stmts['name
                        '] ?></td>
                    <tr>

          <?php endforeach; ?>
</body>   
</html>