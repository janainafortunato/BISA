<?php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', 'tecnologia');
define('DB_NAME', 'bisa');
  
// habilita todas as exibições de erros
ini_set('display_errors', true);
error_reporting(E_ALL);

  
// inclui o arquivo de funções
require_once 'functions.php';

?>