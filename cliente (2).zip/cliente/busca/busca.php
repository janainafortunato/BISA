<?php

require_once 'init.php';

?>

<!DOCTYPE HTML>
<html>
<head>
    <meta charset="utf-8">
    <title>Listagem de Clientes</title>
</head>
<body>
    <div class='container'>
        <fieldset>
 
            <legend><h1>Listagem de Clientes</h1></legend>
 
            <form action="" method="GET" id='form-contato' class="form-horizontal col-md-10">
                <label class="col-md-2 control-label" for="termo">Pesquisar</label>
                <div class='col-md-7'>
                    <input type="text" class="form-control" id="termo" name="termo" placeholder="Infome o Nome ou E-mail">
                </div>
                <button type="submit" class="btn btn-primary">Pesquisar</button>
                <a href='cadastro/index.php' class="btn btn-primary">Ver Todos</a>
            </form>
 
            <a href='cadastro/form-add.php' class="btn btn-success pull-right">Volta</a>
            <div class='clearfix'></div>
 
                <table class="table table-striped">
                    <tr class='active'>
                        <th>Nome</th>
                        <th>E-mail</th>
                        <th>Ação</th>
                    </tr>
                    <?php foreach($PDO as $PDOs): ?>
                        <tr>
                            <td><?php echo $PDO['name'] ?></td>
                            <td><?php echo $PDOs['email'] ?></td>
                        </tr>   
                    <?php endforeach; ?>
                </table>
        </fieldset>
    </div>
 </body>
</html>