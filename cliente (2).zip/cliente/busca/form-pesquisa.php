<!doctype html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Sistema de Busca - ULTIMATE PHP</title>
    </head>
 
    <body>
         
 
<h1>Sistema de Busca - ULTIMATE PHP</h1>
 
 
 
<form action="add-pesquisa.php" method="POST">
            <label for="search">Busca: </label>
            <input type="text" name="search" id="search" placeholder="Busca...">
             
             
 
             
            <label for="cliente">Categoria: </label>
            <select name="cliente" id="cliente">
<option value="">TOdos </option>
<option value="1">Nome</option>
<option value="2">email</option>
<!--<option value="3">Livros</option>
<option value="4">Música</option>-->
            </select>
 
             
 
 
            <input type="submit" value="Buscar">
        </form>
 
 
    </body>
</html>