<?php

require 'init.php';


if(isset($_POST['pesquisa']) &&!empty($_POST['busca'])){
	$name = $_POST['busca'];
	$PDO = db_connect();
	$sql = ("SELECT * FROM users WHERE name LIKE : valor");
	$stmt  =$PDO->prepare($sql);
	$stmt->bindValue(':valor', '%'. $name . '%', PDO::PARAM_STR);
	$stmt->execute();
	$respostas = $stmt->rowCount();
	

	if($respostas >=1){

		echo "Respostas(s) encontrado(s): " .$respostas . "<br/><br />";
		while ($reg->$stmt->fetch(PDO::FETCH_OBJ)) {
			
			echo $reg['name'] . "-";
			echo $reg['email'] ."</br>";
			
		}
	} 
	else{
		echo "Não existe usuario cadastrado";
	}
}
else {
	echo "Preencha o campo de pesquisa";
}

?>

<?php
/*
// Recebe o termo de pesquisa se existir
$termo = (isset($_GET['termo'])) ? $_GET['termo'] : '';
 
// Verifica se o termo de pesquisa está vazio, se estiver executa uma consulta completa
if (empty($termo)):
 
	$PDO = db_connect::getInstance();
	$sql = 'SELECT id, name, email FROM users';
	$stm = $PDO->prepare($sql);
	$stm->execute();
	$clientes = $stm->fetchAll(PDO::FETCH_OBJ);
 
else:
 
	// Executa uma consulta baseada no termo de pesquisa passado como parâmetro
	$PDO = db_connect::getInstance();
	$sql = 'SELECT id, name, email FROM users WHERE name LIKE :name OR email LIKE :email';
	$stm = $PDO->prepare($sql);
	$stm->bindValue(':name', '%'.$termo.'%');
	$stm->bindValue(':email','%'.$termo.'%');
	$stm->execute();
	$clientes = $stm->fetchAll(PDO::FETCH_OBJ);
 
endif;

*/
?>