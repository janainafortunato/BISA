<?php

//require_once 'init.php';

?>

<!DOCTYPE HTML>
<html>
<head>
    <meta charset="utf-8">
    <title>Listagem de Clientes</title>
</head>
<body>
   
 
            <legend><h1>Listagem de Clientes</h1></legend>
 
            <form action="add-busca.php" method="POST">
                <label for="pesquisa">Pesquisar</label>
                    <input type="text" id="pesquisa" name="pesquisa" placeholder="Infome o Nome ou E-mail">
          
                <button type="submit" name="busca">Pesquisar</button>
                <a href='index.php'>Ver Todos</a>
            </form>
 
            <a href='form-add.php'>Volta</a>
           
 
               

</body>
</html>