<?php
	function db_connect(){

		try{

		$PDO = new PDO('mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8', DB_USER, DB_PASS);

		return $PDO;
	
	} catch (PDOException $e){


    echo 'Erro ao conectar com o MySQL: ' . $e->getMessage();

		}



	}
	

?>