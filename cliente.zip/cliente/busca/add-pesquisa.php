<?php

require_once 'init.php';

?>

<?php
 if (!empty($cliente)){

    $filter[]  = [
        'sql' => '( id LIKE :search OR name LIKE :search)',
        'value' => '%' . $search . '%',
        'param_type' => PDO::PARAM_STR,
    ];
} 
 
if (!empty($cliente))
{
    $filters[] = [
        'placeholder' => ':name',
        'sql' => 'name = :name',
        'value' => $cliente,
        'param_type' => PDO::PARAM_INT,
    ];
}
 
foreach ($filters as  $filter)
{
    $sql .= " AND " . $filter['search'];
}
 
// abre a conexão e define codificação UTF-8
$PDO = new PDO('mysql:host=' . DB_HOST . ';dbname=' . DB_NAME, DB_USER, DB_PASS);
$PDO->exec("set names utf8");
 
// cria o Prepared Statement
$stmt = $PDO->prepare($sql);
 
// faz o bind dos valores dos filtros
foreach ($filters as  $filter)
{
    $stmt->bindValue($filters['placeholder'], $filters['value'], $filters['param_type']);
}
 
// executa a query
$stmt->execute();
 
// cria um array com os resultados
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!doctype html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Resultado da Busca </title>
    </head>
 
    <body>
         
 
<h1>Resultados da busca</h1>
 
 
        <?php if (count($users) > 0): ?>
         
        <?php foreach ($users as $user): ?>
             
 
<div>
 
<h2><?php echo $user['name'] ?></h2>
 
 
 <h2><?php echo $user['email']  ?></h2>
 
<?php //echo number_format($product['price'], 2, ',', '.') ?>
 
 
 
<?php //echo $product['description'] ?>
 
            </div>
 
             
 
        <?php endforeach; ?>
 
        <?php else: ?>

        Nenhum resultado encontrado
 
 
        <?php endif; ?>
 
    </body>
</html>



