<?php

require 'init.php';


// Recebe o termo de pesquisa se existir
$termo = (isset($_GET['termo'])) ? $_GET['termo'] : '';
 
// Verifica se o termo de pesquisa está vazio, se estiver executa uma consulta completa
if (empty($termo)):
 
	$PDO = db_connect::getInstance();
	$sql = 'SELECT id, name, email FROM users';
	$stm = $PDO->prepare($sql);
	$stm->execute();
	$clientes = $stm->fetchAll(PDO::FETCH_OBJ);
 
else:
 
	// Executa uma consulta baseada no termo de pesquisa passado como parâmetro
	$PDO = db_connect::getInstance();
	$sql = 'SELECT id, name, email FROM users WHERE name LIKE :name OR email LIKE :email';
	$stm = $PDO->prepare($sql);
	$stm->bindValue(':name', '%'.$termo.'%');
	$stm->bindValue(':email','%'.$termo.'%');
	$stm->execute();
	$clientes = $stm->fetchAll(PDO::FETCH_OBJ);
 
endif;

?>
