<?php

//require_once 'init.php';

?>

<!DOCTYPE HTML>
<html>
<head>
    <meta charset="utf-8">
    <title>Listagem de Clientes</title>
</head>
<body>
    <div class='container'>
        <fieldset>
 
            <legend><h1>Listagem de Clientes</h1></legend>
 
            <form action="" method="GET" id='form-contato' class="form-horizontal col-md-10">
                <label class="col-md-2 control-label" for="termo">Pesquisar</label>
                <div class='col-md-7'>
                    <input type="text" class="form-control" id="termo" name="termo" placeholder="Infome o Nome ou E-mail">
                </div>
                <button type="submit" class="btn btn-primary">Pesquisar</button>
                <a href='index.php' class="btn btn-primary">Ver Todos</a>
            </form>
 
            <a href='form-add.php' class="btn btn-success pull-right">Volta</a>
            <div class='clearfix'></div>
 
                <table class="table table-striped">
                    <tr class='active'>
                        <th>Nome</th>
                        <th>E-mail</th>
                        <th>Ação</th>
                    </tr>
                    <?php foreach($users as $user):?>
                        <tr>
                            <td><?=$user->name?></td>
                            <td><?=$user->email?></td>
                            <td>
                                <a href='editar.php?id=<?=$cliente->id?>' class="btn btn-primary">Editar</a>
                                <a href='javascript:void(0)' class="btn btn-danger link_exclusao" rel="<?=$cliente->id?>">Excluir</a>
                            </td>
                        </tr>   
                    <?php endforeach;?>
                </table>
        </fieldset>
    </div>
    <script type="text/javascript" src="js/custom.js"></script>
</body>
</html>