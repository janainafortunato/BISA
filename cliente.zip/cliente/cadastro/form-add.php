<?php

require 'init.php';

?>
<!DOCTYPE HTML>
<html>
    <head>
        <meta charset="utf-8">
 
        <title>Cadastro de Usuário</title>
    </head>
 
    <body>
 
        <h1>Sistema de Cadastro</h1>
 
        <h2>Cadastro de Usuário</h2>
         
        <form action="add.php" method="POST">
            <label for="name">Nome: </label>
            <br>
            <input type="text" name="name" id="name">
 
            <br><br>
 
            <label for="email">Email: </label>
            <br>
            <input type="text" name="email" id="email">
 
            <input type="submit" value="Cadastrar">
        </form>
 
    </body>
</html>